-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2018 at 11:42 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `MobileNo` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `MobileNo`, `year`, `email`, `password`) VALUES
(1, 'pranjali', 2147483647, 1, 'pranjali.3898@gmail.com', '097809d51ee7eb71de441bd1421f2a53'),
(2, 'qwerty', 1234567890, 2, 'kushagra@iitk.ac.in', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(3, 'qwerty', 1234567890, 2, 'kushagra@iitk.ac.in', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(4, 'qwerty', 987654321, 1, 'cutieastha04@gmail.com', '202cb962ac59075b964b07152d234b70'),
(7, 'pranjali', 2147483647, 1, 'pranjali.3898@gmail.com', '097809d51ee7eb71de441bd1421f2a53'),
(8, 'pranjali', 1234567890, 4, 'cutieastha04@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(9, 'pranjali', 2147483647, 1, 'pranjali.3898@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(10, 'kirti2', 2147483647, 1, 'kushagra@iitk.ac.in', '006d2143154327a64d86a264aea225f3'),
(11, 'pranjali', 2147483647, 1, 'pranjali.3898@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(12, 'pranjali', 2147483647, 1, 'pranjali.3898@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(13, 'pranjali', 2147483647, 1, 'pranjali.3898@gmail.com', '7694f4a66316e53c8cdd9d9954bd611d'),
(14, 'pranjali', 2147483647, 1, 'pranjali.3898@gmail.com', '7694f4a66316e53c8cdd9d9954bd611d'),
(15, 'kush', 2147483647, 1, 'kushagra@iitk.ac.in', '006d2143154327a64d86a264aea225f3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
